<?php

$host = "localhost";
$user = "phpuser";
$password = "php123";
$db = "schoolproject"; 

$conn = mysqli_connect($host, $user, $password, $db);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();



if (isset($_SESSION['username'])) {
    $loggedInUsername = $_SESSION['username'];
  
    
} else {
    $loggedInUsername = "Welcome";

}

?>

<!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>EduLanka</title>

            <!--favicon-->
            <link rel="apple-touch-icon" sizes="180x180" href="./favicon/apple-touch-icon.png">
            <link rel="icon" type="image/png" sizes="32x32" href="./favicon/favicon-32x32.png">
            <link rel="icon" type="image/png" sizes="16x16" href="./favicon/favicon-16x16.png">
            <link rel="manifest" href="./favicon/site.webmanifest">
            <link rel="mask-icon" href="./favicon/safari-pinned-tab.svg" color="#5bbad5">
            <meta name="msapplication-TileColor" content="#da532c">
            <meta name="theme-color" content="#ffffff">
        
        <link rel="stylesheet" href=" Style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
        <style>
        /* Custom styles */
        .custom-card {
            margin: 10px auto;
            /* padding-bottom: 10px; */
        }

        .card{
            background-image: linear-gradient(to right, #ebd8e3 , #d6a5c2);
        }
    </style>
    </head>

    <body>
    <nav class="navbar" style="background-color: #fcd9d9;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <div class="d-flex align-items-center">
                <img src="./images/icon.png" alt="Logo" width="100" height="100" class="d-inline-block align-text-top">
                <h1 class="mb-0 ml-3">Teacher</h1>
            </div>
        </a>

            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $loggedInUsername; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="editprofile.php">Edit Profile</a></li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </div>
    </div>
    </nav>

    <center>
    <h1>Select grade</h1>
    </center>

    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 4</h5>
                <a href="teacher/teacher4.php" class="btn btn-primary">Go to Grade 4</a>
            </div>
            </div>
        </div>

        <div class="col-sm-6 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 5</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 6</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
        <div class="col-sm-6 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 7</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 8</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
        <div class="col-sm-6 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 9</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 10</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
        <div class="col-sm-6 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 11</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 12</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
        <div class="col-sm-6 p-5 custom-card">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Grade 13</h5>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            </div>
        </div>
    </div>

    <br>
    <footer class="footer">
    <div class="footer-content">
      <div class="contact-info">
        <h3>Contact Us</h3>
        <p>Email: edulanka@gmail.com</p>
        <p>Phone: (+94)77 564 0931</p>
      </div>
      <div class="social-media">
        <h3>Follow Us</h3>
        <div class="social-icons">
          <a href="#" class="icon-link"><i class="fab fa-facebook"></i></a>
          <a href="#" class="icon-link"><i class="fab fa-twitter"></i></a>
          <a href="#" class="icon-link"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <p class="footer-text">&copy; 2023 EduLanka. All rights reserved.</p>
  </footer>
  



        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
        <script>

    </body>
    </html>
