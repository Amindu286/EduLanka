<?php

$host = "localhost";
$user = "phpuser";
$password = "php123";
$db = "schoolproject"; 

$conn = mysqli_connect($host, $user, $password, $db);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();



if (isset($_SESSION['username'])) {
    $loggedInUsername = $_SESSION['username'];
  
    
} else {
    $loggedInUsername = "Welcome";

}


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_FILES['file'])) {
        $title = $_POST['title'];
        $filename = $_FILES['file']['name'];
        $filetype = $_FILES['file']['type'];
        $file = $_FILES['file']['tmp_name'];

        // Check if the uploaded file is a PDF, DOCX, or PPT
        $allowedExtensions = array('pdf', 'docx', 'ppt');
        $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!in_array($fileExtension, $allowedExtensions)) {
            echo "Only PDF, DOCX, and PPT files are allowed.";
            exit;
        }

        // Move the uploaded file to a directory
        $uploadDirectory = '../teacher/uploads/';
        $newFilePath = $uploadDirectory . $filename;
        if (move_uploaded_file($file, $newFilePath)) {
            // Insert data into the database
            $query = "INSERT INTO lecture_materials (title, filename) VALUES ('$title', '$filename')";
            if (mysqli_query($conn, $query)) {
                echo "<script type ='text/javascript'> alert('Files Upload Success');</script>";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "<script type ='text/javascript'> alert('File Upload Failed');</script>";
        }
    }

    if (isset($_POST['sub_link'])) {
        $title = $_POST['title'];
        $link = $_POST['link'];

        // Check if any of the fields are empty
        if (empty($title) || empty($link)) {
            echo "<script type='text/javascript'> alert('Please fill in all fields');</script>";
        } else {
            $sql = "INSERT INTO links (title, link) VALUES ('$title', '$link')";
            if (mysqli_query($conn, $sql)) {
                echo "<script type ='text/javascript'> alert('Link Upload Success');</script>";
            } else {
                echo "<script type ='text/javascript'> alert('Link Upload Failed');</script>";
            }
        }
    }

    
    if (isset($_POST['sub_quiz'])) {
        $quizno = $_POST['quizno'];
        $quizlink = $_POST['quizlink'];

        // Check if any of the fields are empty
        if (empty($quizno) || empty($quizlink)) {
            echo "<script type='text/javascript'> alert('Please fill in all fields');</script>";
        } else {
            $sql2 = "INSERT INTO quiz (quizno, quizlink) VALUES ('$quizno', '$quizlink')";
            if (mysqli_query($conn, $sql2)) {
                echo "<script type ='text/javascript'> alert('Link Upload Success');</script>";
            } else {
                echo "<script type ='text/javascript'> alert('Link Upload Failed');</script>";
            }
        }
    }
}



?>

<!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>EduLanka</title>

            <!--favicon-->
            <link rel="apple-touch-icon" sizes="180x180" href="../favicon/apple-touch-icon.png">
            <link rel="icon" type="image/png" sizes="32x32" href="../favicon/favicon-32x32.png">
            <link rel="icon" type="image/png" sizes="16x16" href="../favicon/favicon-16x16.png">
            <link rel="manifest" href="../favicon/site.webmanifest">
            <link rel="mask-icon" href="../favicon/safari-pinned-tab.svg" color="#5bbad5">
            <meta name="msapplication-TileColor" content="#da532c">
            <meta name="theme-color" content="#ffffff">

            <style>
                .container{
                    background-color:#bbff91;
                    border-radius:15px;
                }

                .main{
                    background-color:#bdbdbd;
                }
            </style>
        
        <link rel="stylesheet" href=" Style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    </head>

    <body>
    <nav class="navbar" style="background-color: #bbff91;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <div class="d-flex align-items-center">
                <img src="../images/icon.png" alt="Logo" width="100" height="100" class="d-inline-block align-text-top">
                <h1 class="mb-0 ml-3">Grade 4 Teacher</h1>
            </div>
        </a>

            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $loggedInUsername; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="../editprofile.php">Edit Profile</a></li>
                    <li><a class="dropdown-item" href="../logout.php">Logout</a></li> 
                </ul>
            </div>
    </div>
    </nav>

    <section class="main">

    <br>

    <div class="hstack gap-4 px-5 ">
        <div class="bg-transparent border text-dark"><a href="#sect1">Upload Resources</a></div>
        <div class="bg-transparent border text-dark"><a href="#sect2">View Resources</a></div>
        <div class="bg-transparent border text-dark"><a href="#sect3">Upload Links</a></div>
        <div class="bg-transparent border text-dark"><a href="#sect4">View links</a></div>
    </div>


<!--upload resources-->
    <div class="container mt-4 ">
        <h2 id="sect1">Upload Resources</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="mb-3">
                <label for="file" class="form-label">File (PDF, DOCX, PPT)</label>
                <input type="file" class="form-control" id="file" name="file" accept=".pdf,.docx,.ppt" required>
            </div>
            <button type="submit" class="btn btn-primary mb-3">Upload and Save</button>
        </form>
    </div>
    <hr class="hr" />

    <br><br>
<!--View resources-->
    <div class="container mt-4">
    <h2 id="sect2">Resources</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Title</th>
                <th>File</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $lecture_query = "SELECT * FROM lecture_materials";
            $lecture_result = mysqli_query($conn, $lecture_query);

            while ($row = mysqli_fetch_assoc($lecture_result)) {
                $title = $row['title'];
                $filename = $row['filename'];
                $fileUrl = 'teacher/uploads/' . $filename;
                echo "<tr>";
                echo "<td>$title</td>";
                echo "<td><a href='$fileUrl' download>Download</a></td>";
                echo "</tr>";
            }

            mysqli_free_result($lecture_result);
            ?>
        </tbody>
    </table>
</div>

<hr class="hr" />
<br><br>


<!--upload class link-->
<div class="container mt-3 mb-3">
    <h1 id="sect3">Submit Links</h1>
    <form action="#" method="POST" enctype="multipart/form-data">
        <div class="div_deg">
            <div>
                <label for="">Title</label>
                <input type="text" name="title">
            </div>
            <br>
            <div>
                <label for="">Link</label>
                <input type="url" name="link">
            </div>
            <br>
            <p class="warning">Make sure that you enter the correct link</p>
            <div>
                <input type="submit" name="sub_link" value="Submit the link" class="btn btn-danger mb-3">
            </div>
        </div>
    </form>
</div>
<hr class="hr" />


<br><br>

<!--View Class links-->
<div class="container mt-4">
    <h1 id="sect4">Class Links</h1>
    <br>
    <table class="table">
        <tr class="tr">
            <th>Title</th>
            <th>Link</th>
            <th>Action</th>
        </tr>

        <?php
        $selectQuery = "SELECT * FROM links";
        $result = mysqli_query($conn, $selectQuery);

        while ($info = mysqli_fetch_assoc($result)) {
            ?>
            <tr class="tr">
                <td><?php echo $info['title']; ?></td>
                <td><a href="<?php echo $info['link']; ?>" target="_blank"><?php echo $info['link']; ?></a></td>
                <td>
                    <a href="delete_link.php?id=<?php echo $info['id']; ?>" class="btn btn-danger btn-sm mb-3">Delete</a>
                </td>
            </tr>
            <?php
        }
        ?>

    </table>
</div>

<hr class="hr" />
<br><br>


<!--upload Quizzes-->
<div class="container mt-3 mb-3">
    <h1 id="sect3">Upload Quizzes</h1>
    <form action="#" method="POST" enctype="multipart/form-data">
        <div class="div_deg">
            <div>
                <label for="">Quiz Number</label>
                <input type="text" name="quizno">
            </div>
            <br>
            <div>
                <label for="">Quiz Link (Google Form, FlexiQuiz etc...)</label>
                <input type="url" name="quizlink">
            </div>
            <br>
            <p class="warning">Make sure that you enter the correct link</p>
            <div>
                <input type="submit" name="sub_quiz" value="Submit Quiz" class="btn btn-danger mb-3">
            </div>
        </div>
    </form>
</div>

<br>
<div class="container">
        <div class="row">
            <div class="col-md-6 px-5">
                <div class="chat-container">
                    <div class="chat-messages" id="chat-messages">
                    </div>
                    <div class="chat-input">
                        <input type="text" id="message" placeholder="Type your message">
                        <button id="send" class="btn btn-primary">Send</button>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="quote">
                    <p><center>Ask any questions using our chat.</center></p>
                </div>
            </div>
        </div>
    </div>
    <br>


    </section>

    <br>
    <footer class="footer">
    <div class="footer-content">
      <div class="contact-info">
        <h3>Contact Us</h3>
        <p>Email: edulanka@gmail.com</p>
        <p>Phone: (+94)77 564 0931</p>
      </div>
      <div class="social-media">
        <h3>Follow Us</h3>
        <div class="social-icons">
          <a href="#" class="icon-link"><i class="fab fa-facebook"></i></a>
          <a href="#" class="icon-link"><i class="fab fa-twitter"></i></a>
          <a href="#" class="icon-link"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <p class="footer-text">&copy; 2023 EduLanka. All rights reserved.</p>
  </footer>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
        <script>

    </body>
    </html>
